<html>
    <head>
<style>
    *{
    margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
img{
    margin: px;
    width: 40px;
    height: 40px;
}
    </style>
</head>
</html>


<?php
require('allconnection.php');
$sql="select * from student1";
$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result)>0){
    echo "<table border='1' cellpadding='0' cellspacing='0'><tr>
       <th>Userid</th><th>Mobile_Number</th><th>Email_id</th><th>Gender</th>
       <th>photo</th><th>edit</th></tr>";
    while($row=mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>".$row['userid']."</td><td>".$row['mobile_number']."</td><td>".$row['email_id']."</td><td>".$row['gender']."</td>";
       ?>
        <td><img src="./uploads/<?php echo $row['upload']; ?>"></td>
        <td align='center'><button Class='delete-btn' name=$row[]>Delete</button></td>;
 
 <?php
    }
    echo "</tr></table>";
}


?>



